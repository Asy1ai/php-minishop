<?php
require_once '../includes/auth.php';
require_admin();

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;

$product = ['name' => '', 'description' => '', 'price' => '', 'stock' => '0', 'category' => '', 'image' => null];

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        flash_set('Тауар табылмады.', 'error');
        header('Location: products.php');
        exit;
    }
    $product = $row;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $errors[] = 'Қауіпсіздік қатесі. Бетті жаңартып, қайта көріңіз.';
    }

    $name        = trim($_POST['name'] ?? '');
    $category    = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $priceRaw    = str_replace(',', '.', trim($_POST['price'] ?? ''));
    $stockRaw    = trim($_POST['stock'] ?? '');

    $product = array_merge($product, [
        'name' => $name, 'category' => $category, 'description' => $description,
        'price' => $priceRaw, 'stock' => $stockRaw,
    ]);

    if (mb_strlen($name) < 2 || mb_strlen($name) > 150) {
        $errors[] = 'Атауы 2–150 таңба аралығында болуы керек.';
    }
    if (mb_strlen($category) > 50) {
        $errors[] = 'Санат 50 таңбадан аспауы керек.';
    }
    if (mb_strlen($description) > 2000) {
        $errors[] = 'Сипаттама 2000 таңбадан аспауы керек.';
    }
    if (!is_numeric($priceRaw) || $priceRaw < 0 || $priceRaw > 99999999) {
        $errors[] = 'Баға дұрыс емес (0 немесе одан көп сан).';
    }
    if (filter_var($stockRaw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 1000000]]) === false) {
        $errors[] = 'Қоймадағы саны — 0 немесе одан көп бүтін сан болуы керек.';
    }

    $newImage = null;
    if (!$errors) {
        $newImage = save_upload($_FILES['image'] ?? ['error' => UPLOAD_ERR_NO_FILE], $errors);
    }

    if (!$errors) {
        if ($id) {
            $image = $newImage ?? $product['image'];
            $stmt = $pdo->prepare(
                'UPDATE products SET name = ?, description = ?, price = ?, stock = ?, category = ?, image = ? WHERE id = ?'
            );
            $stmt->execute([$name, $description, $priceRaw, (int)$stockRaw, $category, $image, $id]);
            if ($newImage) {
                delete_upload($product['image']);
            }
            flash_set('Тауар сәтті жаңартылды.');
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO products (name, description, price, stock, category, image) VALUES (?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([$name, $description, $priceRaw, (int)$stockRaw, $category, $newImage]);
            flash_set('Тауар сәтті қосылды.');
        }
        header('Location: products.php');
        exit;
    }
}

$isEdit    = $id > 0;
$pageTitle = ($isEdit ? 'Тауарды өңдеу' : 'Жаңа тауар') . ' — MiniShop';
require '../includes/header.php';
$img = product_image_url($product['image']);
?>
<div class="container section-space">
    <a class="muted" href="products.php">← Тізімге оралу</a>
    <p class="eyebrow" style="margin-top:14px">ӘКІМШІ ПАНЕЛІ</p>
    <h1><?= $isEdit ? 'Тауарды өңдеу' : 'Жаңа тауар қосу' ?></h1>

    <div class="form-card">
        <?php if ($errors): ?>
            <div class="alert error">
                <ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
            </div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data"
              action="product_form.php<?= $isEdit ? '?id=' . (int)$id : '' ?>" novalidate>
            <?= csrf_field() ?>

            <label for="name">Атауы</label>
            <input id="name" name="name" type="text" required value="<?= e($product['name']) ?>">

            <div class="form-row">
                <div>
                    <label for="price">Бағасы (₸)</label>
                    <input id="price" name="price" type="number" step="0.01" min="0" required
                           value="<?= e((string)$product['price']) ?>">
                </div>
                <div>
                    <label for="stock">Қоймадағы саны</label>
                    <input id="stock" name="stock" type="number" step="1" min="0" required
                           value="<?= e((string)$product['stock']) ?>">
                </div>
            </div>

            <label for="category">Санат</label>
            <input id="category" name="category" type="text" maxlength="50"
                   placeholder="мысалы: Электроника" value="<?= e($product['category']) ?>">

            <label for="description">Сипаттама</label>
            <textarea id="description" name="description" rows="5"><?= e($product['description']) ?></textarea>

            <label for="image">Сурет (JPG / PNG / WEBP, ≤ 2 МБ)</label>
            <?php if ($img): ?>
                <p><img class="thumb" style="width:90px;height:90px" src="<?= e($img) ?>" alt="">
                   <span class="muted">Қазіргі сурет. Жаңасын таңдасаңыз ауысады.</span></p>
            <?php endif; ?>
            <input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp">

            <button class="btn full-width" type="submit" style="margin-top:20px">
                <?= $isEdit ? 'Өзгерістерді сақтау' : 'Тауарды қосу' ?>
            </button>
        </form>
    </div>
</div>
<?php require '../includes/footer.php'; ?>
