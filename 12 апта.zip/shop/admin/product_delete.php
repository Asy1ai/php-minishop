<?php
require_once '../includes/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_check()) {
    flash_set('Қауіпсіздік қатесі. Әрекет орындалмады.', 'error');
    header('Location: products.php');
    exit;
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if ($id) {
    $stmt = $pdo->prepare('SELECT image FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();

    if ($row) {
        $del = $pdo->prepare('DELETE FROM products WHERE id = ?');
        $del->execute([$id]);
        delete_upload($row['image']);
        flash_set('Тауар жойылды.');
    } else {
        flash_set('Тауар табылмады.', 'error');
    }
} else {
    flash_set('Қате тауар нөмірі.', 'error');
}

header('Location: products.php');
exit;
