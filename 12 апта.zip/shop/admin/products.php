<?php
require_once '../includes/auth.php';
require_admin();

$products = $pdo->query('SELECT * FROM products ORDER BY id DESC')->fetchAll();

$pageTitle = 'Тауарларды басқару — MiniShop';
require '../includes/header.php';
?>
<div class="container section-space">
    <?php if ($flash): ?>
        <div class="alert <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
    <?php endif; ?>

    <div class="page-head">
        <div>
            <p class="eyebrow">ӘКІМШІ ПАНЕЛІ</p>
            <h1>Тауарларды басқару</h1>
        </div>
        <a class="btn" href="product_form.php">+ Тауар қосу</a>
    </div>

    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr><th>ID</th><th>Сурет</th><th>Атауы</th><th>Санат</th><th>Бағасы</th><th>Қоймада</th><th>Әрекет</th></tr>
            </thead>
            <tbody>
            <?php if (!$products): ?>
                <tr><td colspan="7" class="muted">Тауар жоқ. «Тауар қосу» батырмасын басыңыз.</td></tr>
            <?php endif; ?>
            <?php foreach ($products as $p): $img = product_image_url($p['image']); ?>
                <tr>
                    <td><?= (int)$p['id'] ?></td>
                    <td>
                        <?php if ($img): ?><img class="thumb" src="<?= e($img) ?>" alt="">
                        <?php else: ?><div class="thumb no-image" style="font-size:20px">🛍️</div><?php endif; ?>
                    </td>
                    <td><?= e($p['name']) ?></td>
                    <td><?= e($p['category']) ?></td>
                    <td><?= e(money($p['price'])) ?></td>
                    <td><?= (int)$p['stock'] ?></td>
                    <td>
                        <div class="actions">
                            <a class="btn secondary btn-sm" href="product_form.php?id=<?= (int)$p['id'] ?>">Өңдеу</a>
                            <form method="post" action="product_delete.php"
                                  onsubmit="return confirm('Бұл тауарды жоясыз ба?');">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                                <button type="submit" class="btn danger btn-sm">Жою</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require '../includes/footer.php'; ?>
