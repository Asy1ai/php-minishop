<?php
require_once 'includes/auth.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

$product = false;
if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([$id]);
    $product = $stmt->fetch();
}

if (!$product) {
    http_response_code(404);
    $pageTitle = 'Тауар табылмады — MiniShop';
    require 'includes/header.php';
    echo '<div class="container section-space"><div class="empty-box">'
       . '<p class="muted">Тауар табылмады.</p><a class="btn" href="products.php">Каталогқа оралу</a></div></div>';
    require 'includes/footer.php';
    exit;
}

$img = product_image_url($product['image']);
$pageTitle = $product['name'] . ' — MiniShop';
require 'includes/header.php';
?>
<div class="container section-space">
    <a class="muted" href="products.php">← Каталогқа оралу</a>

    <div class="product-detail">
        <?php if ($img): ?>
            <img src="<?= e($img) ?>" alt="<?= e($product['name']) ?>">
        <?php else: ?>
            <div class="no-image product-image" style="height:340px">🛍️</div>
        <?php endif; ?>

        <div>
            <p class="product-category"><?= e($product['category'] ?: 'Санатсыз') ?></p>
            <h1><?= e($product['name']) ?></h1>
            <p class="price" style="font-size:26px"><?= e(money($product['price'])) ?></p>
            <p><?= nl2br(e($product['description'])) ?></p>
            <p class="muted">Қоймада: <?= (int)$product['stock'] ?> дана</p>

            <?php if (is_admin()): ?>
                <a class="btn secondary" href="admin/product_form.php?id=<?= (int)$product['id'] ?>">Өңдеу</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
