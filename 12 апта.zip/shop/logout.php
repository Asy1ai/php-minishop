<?php
require_once 'includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_check()) {
    logout_user();
    session_start();
    flash_set('Сіз жүйеден шықтыңыз.');
}

header('Location: login.php');
exit;
