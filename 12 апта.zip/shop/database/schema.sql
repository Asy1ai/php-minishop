CREATE DATABASE IF NOT EXISTS minishop
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE minishop;

CREATE TABLE IF NOT EXISTS users (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(100) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  role       ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  description TEXT,
  price       DECIMAL(10,2) NOT NULL DEFAULT 0,
  stock       INT UNSIGNED NOT NULL DEFAULT 0,
  category    VARCHAR(50) NOT NULL DEFAULT '',
  image       VARCHAR(255) DEFAULT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO products (name, description, price, stock, category) VALUES
('Сымсыз құлаққап', 'Bluetooth 5.3, 30 сағатқа дейін жұмыс істейді.', 18900, 25, 'Электроника'),
('Смарт сағат', 'Қадам, пульс және ұйқыны бақылайды.', 32500, 12, 'Электроника'),
('Рюкзак', 'Ноутбукке арналған бөлімі бар, су өткізбейді.', 12400, 40, 'Аксессуарлар'),
('Термос 500 мл', 'Ыстықты 12 сағат сақтайды.', 6800, 60, 'Үй және ас үй'),
('Үстел шамы', 'LED, жарықтығы реттеледі.', 9500, 18, 'Үй және ас үй'),
('Спорт бөтелкесі', 'BPA жоқ, 750 мл.', 3200, 100, 'Спорт');
