<?php
require_once __DIR__ . '/auth.php';
$current   = basename($_SERVER['SCRIPT_NAME']);
$b         = base_path();
$pageTitle = $pageTitle ?? 'MiniShop — Онлайн дүкен';
$flash     = flash_get();
function nav_active(string $file, string $current): string {
    return $file === $current ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle) ?></title>
    <link rel="stylesheet" href="<?= $b ?>assets/css/style.css">
    <script src="<?= $b ?>assets/js/main.js" defer></script>
</head>
<body>

<header>
    <div class="container navbar">
        <a href="<?= $b ?>index.php" class="logo">Mini<span>Shop</span></a>

        <button class="menu-btn" id="menuBtn" type="button">☰</button>

        <nav id="nav">
            <a href="<?= $b ?>index.php"    class="<?= nav_active('index.php', $current) ?>">Басты бет</a>
            <a href="<?= $b ?>products.php" class="<?= nav_active('products.php', $current) ?>">Тауарлар</a>
            <a href="<?= $b ?>cart.php"     class="<?= nav_active('cart.php', $current) ?>">Себет 🛒</a>

            <?php if (is_admin()): ?>
                <a href="<?= $b ?>admin/products.php" class="<?= $b !== '' ? 'active' : '' ?>">⚙️ Басқару</a>
            <?php endif; ?>

            <?php if (is_logged_in()): ?>
                <a href="<?= $b ?>profile.php" class="<?= nav_active('profile.php', $current) ?>">
                    👤 <?= e($_SESSION['name']) ?>
                </a>
                <form method="post" action="<?= $b ?>logout.php">
                    <?= csrf_field() ?>
                    <button type="submit" class="logout-btn">Шығу</button>
                </form>
            <?php else: ?>
                <a href="<?= $b ?>login.php" class="<?= nav_active('login.php', $current) ?>">Кіру</a>
                <a href="<?= $b ?>register.php" class="nav-button">Тіркелу</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<main>
