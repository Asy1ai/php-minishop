<?php
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function e(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function is_logged_in(): bool {
    return isset($_SESSION['user_id']);
}

function is_admin(): bool {
    return is_logged_in() && ($_SESSION['role'] ?? '') === 'admin';
}

function require_login(): void {
    if (!is_logged_in()) {
        $next = basename($_SERVER['SCRIPT_NAME']);
        flash_set('Бұл бетті көру үшін алдымен жүйеге кіріңіз.', 'error');
        header('Location: ' . base_path() . 'login.php?next=' . urlencode($next));
        exit;
    }
}

function redirect_if_logged_in(): void {
    if (is_logged_in()) {
        header('Location: profile.php');
        exit;
    }
}

function login_user(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['name']    = $user['name'];
    $_SESSION['role']    = $user['role'];
}

function logout_user(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): bool {
    return isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

function flash_set(string $msg, string $type = 'success'): void {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function flash_get(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

function base_path(): string {
    return basename(dirname($_SERVER['SCRIPT_NAME'])) === 'admin' ? '../' : '';
}

function require_admin(): void {
    if (!is_logged_in()) {
        flash_set('Алдымен жүйеге кіріңіз.', 'error');
        header('Location: ' . base_path() . 'login.php');
        exit;
    }
    if (!is_admin()) {
        flash_set('Бұл бет тек әкімшіге арналған.', 'error');
        header('Location: ' . base_path() . 'index.php');
        exit;
    }
}

function money($v): string {
    return number_format((float)$v, 0, ',', ' ') . ' ₸';
}

function product_image_url(?string $img): ?string {
    return $img ? base_path() . 'uploads/' . rawurlencode($img) : null;
}

function save_upload(array $file, array &$errors): ?string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return null;
    if ($file['error'] !== UPLOAD_ERR_OK) { $errors[] = 'Сурет жүктеу кезінде қате шықты.'; return null; }
    if ($file['size'] > 2 * 1024 * 1024) { $errors[] = 'Сурет 2 МБ-тан аспауы керек.'; return null; }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $ext  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext) { $errors[] = 'Тек JPG, PNG немесе WEBP сурет жүктеңіз.'; return null; }

    $dir = __DIR__ . '/../uploads';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
        $errors[] = 'Суретті сақтау мүмкін болмады.'; return null;
    }
    return $name;
}

function delete_upload(?string $img): void {
    if ($img && preg_match('/^[a-f0-9]{16}\.(jpg|png|webp)$/', $img)) {
        @unlink(__DIR__ . '/../uploads/' . $img);
    }
}
