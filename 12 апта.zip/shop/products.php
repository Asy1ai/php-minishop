<?php
require_once 'includes/auth.php';

$products = $pdo->query(
    'SELECT id, name, price, category, image FROM products ORDER BY id DESC'
)->fetchAll();

$pageTitle = 'Тауарлар — MiniShop';
require 'includes/header.php';
?>
<div class="container section-space">
    <?php if ($flash): ?>
        <div class="alert <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
    <?php endif; ?>

    <p class="eyebrow">MINISHOP КАТАЛОГЫ</p>
    <h1>Барлық тауарлар</h1>
    <p class="muted">Барлығы: <?= count($products) ?> тауар</p>

    <?php if (!$products): ?>
        <div class="empty-box"><p class="muted">Әзірге тауар жоқ.</p></div>
    <?php else: ?>
        <div class="products" style="margin-top:22px">
            <?php foreach ($products as $p): $img = product_image_url($p['image']); ?>
                <div class="product-card">
                    <a href="product.php?id=<?= (int)$p['id'] ?>">
                        <?php if ($img): ?>
                            <img class="product-image" src="<?= e($img) ?>" alt="<?= e($p['name']) ?>">
                        <?php else: ?>
                            <div class="product-image no-image">🛍️</div>
                        <?php endif; ?>
                    </a>
                    <div class="product-info">
                        <p class="product-category"><?= e($p['category'] ?: 'Санатсыз') ?></p>
                        <h3><a href="product.php?id=<?= (int)$p['id'] ?>"><?= e($p['name']) ?></a></h3>
                        <div class="product-bottom">
                            <span class="price"><?= e(money($p['price'])) ?></span>
                            <a class="btn" href="product.php?id=<?= (int)$p['id'] ?>">Көру</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php require 'includes/footer.php'; ?>
