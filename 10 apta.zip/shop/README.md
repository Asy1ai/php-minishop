# MiniShop — шағын онлайн дүкен (PHP + MySQL)
Автор: Болатқызы Асылай · Топ: АЖ-336

## 10-апта: PHP негіздері және серверлік құрылым

| Талап | Қайда орындалған |
|---|---|
| Беттерді PHP-ға көшіру | `index.php`, `products.php`, `product.php`, `cart.php`, `register.php`, `login.php`, `logout.php`, `profile.php` |
| `include` арқылы қайталанатын бөліктер | `includes/header.php`, `includes/footer.php`, `includes/product_card.php`, `includes/init.php` |
| `$_GET` өңдеу | `products.php` (іздеу `q`, санат `category`, сұрыптау `sort`), `product.php` (`id`) |
| `$_POST` өңдеу | `register.php`, `login.php`, `cart.php` |
| Серверде тексеру (валидация) | `register.php` (аты, email, пароль), `login.php`, `cart.php` (саны 1–10) |
| Қауіпсіздік | `e()` = `htmlspecialchars` (XSS), CSRF токен, `password_hash()` / `password_verify()` |
| Жоба қалтасының құрылымы | төмендегі схема |

## Құрылым
```
shop/
├── index.php, products.php, product.php, cart.php
├── register.php, login.php, logout.php, profile.php
├── check.php            (ортаны тексеру)
├── includes/            init.php, header.php, footer.php, product_card.php
├── assets/              css/style.css, js/script.js
├── data/                users.json (11-аптада MySQL-ге ауысады), .htaccess
├── admin/  uploads/  database/   (12–14 апталарға)
```

## Іске қосу (XAMPP)
1. `shop` қалтасын `C:\xampp\htdocs\` ішіне көшіріңіз.
2. XAMPP-та **Apache**-ді қосыңыз.
3. Браузерде `http://localhost/shop/check.php` ашып, барлығы ✅ екенін тексеріңіз.
4. Содан кейін `http://localhost/shop/` ашыңыз.

> `index.php` файлын қос шертіп ашуға болмайды: PHP тек сервер арқылы жұмыс істейді.
