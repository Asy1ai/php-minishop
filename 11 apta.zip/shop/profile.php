<?php
require_once 'includes/auth.php';
require_login();                              // кірмегендерге жабық

$stmt = $pdo->prepare('SELECT name, email, role, created_at FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Пайдаланушы дерекқордан өшіп кетсе — сессияны жабамыз
if (!$user) {
    logout_user();
    header('Location: login.php');
    exit;
}

$pageTitle = 'Профиль — MiniShop';
require 'includes/header.php';
?>
<div class="container section-space">
    <?php if ($flash): ?>
        <div class="alert <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
    <?php endif; ?>

    <div class="profile-card" style="margin-top:20px">
        <div class="auth-icon">👤</div>
        <p class="eyebrow">ЖЕКЕ КАБИНЕТ</p>
        <h1>Менің профилім</h1>

        <p><b>Аты-жөні:</b> <?= e($user['name']) ?></p>
        <p><b>Email:</b> <?= e($user['email']) ?></p>
        <p><b>Рөлі:</b> <span class="role-badge"><?= e($user['role']) ?></span></p>
        <p><b>Тіркелген күні:</b> <?= e($user['created_at']) ?></p>

        <a class="btn" href="cart.php">Себетімді көру</a>
        <a class="btn secondary" href="products.php">Сауданы жалғастыру</a>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
