<?php
require_once 'includes/auth.php';
redirect_if_logged_in();

$errors = [];
$email  = '';

// Кіруден кейін қайда қайту керек (тек қауіпсіз, өз жобамыздағы файл)
$next = $_GET['next'] ?? $_POST['next'] ?? '';
if (!preg_match('/^[a-z_]+\.php$/', $next) || !file_exists(__DIR__ . '/' . $next)) {
    $next = 'profile.php';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $errors[] = 'Қауіпсіздік қатесі. Бетті жаңартып, қайта көріңіз.';
    }

    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$errors) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        // Парольді хэшпен салыстыру
        if ($user && password_verify($password, $user['password'])) {
            login_user($user);
            header('Location: ' . $next);
            exit;
        }
        $errors[] = 'Email немесе құпиясөз қате.';
    }
}

$pageTitle = 'Кіру — MiniShop';
require 'includes/header.php';
?>
<div class="auth-background">
    <div class="auth-card">
        <div class="auth-icon">👋</div>
        <p class="eyebrow">ҚАЙТА ҚОШ КЕЛДІҢІЗ!</p>
        <h1>Жүйеге кіру</h1>
        <p class="muted">Аккаунтыңызға кіріңіз.</p>

        <?php if ($flash): ?>
            <div class="alert <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
        <?php endif; ?>
        <?php foreach ($errors as $err): ?>
            <div class="alert error"><?= e($err) ?></div>
        <?php endforeach; ?>

        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="next" value="<?= e($next) ?>">

            <label for="email">Электрондық пошта</label>
            <input id="email" name="email" type="email" required
                   placeholder="name@example.com" value="<?= e($email) ?>">

            <label for="password">Құпиясөз</label>
            <input id="password" name="password" type="password" required
                   placeholder="Құпиясөзіңіз">

            <button class="btn full-width" type="submit">Кіру</button>
        </form>

        <p class="switch-text">Аккаунтыңыз жоқ па? <a href="register.php"><b>Тіркелу</b></a></p>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
