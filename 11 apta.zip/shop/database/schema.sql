-- MiniShop: 11-апта. Дерекқор және аутентификация
CREATE DATABASE IF NOT EXISTS minishop
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE minishop;

CREATE TABLE IF NOT EXISTS users (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(100) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,               -- password_hash() нәтижесі
  role       ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Әкімші жасау: алдымен сайтта тіркеліп, содан кейін мына сұранысты орындаңыз:
-- UPDATE users SET role = 'admin' WHERE email = 'сіздің@email.com';
