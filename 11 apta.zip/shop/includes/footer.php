</main>

<footer>
    <div class="container footer-content">
        <a href="index.php" class="logo">Mini<span>Shop</span></a>
        <p>© 2026 MiniShop. Оқу жобасы.</p>
        <p>Болатқызы Асылай · АЖ-336</p>
    </div>
</footer>

</body>
</html>
