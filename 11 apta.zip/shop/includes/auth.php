<?php
// Сессия, аутентификация және көмекші функциялар
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,      // JS арқылы cookie оқылмайды
        'samesite' => 'Lax',
    ]);
    session_start();
}

/** XSS-тен қорғау: шығарылатын барлық мәтінді осы арқылы өткізіңіз */
function e(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function is_logged_in(): bool {
    return isset($_SESSION['user_id']);
}

function is_admin(): bool {
    return is_logged_in() && ($_SESSION['role'] ?? '') === 'admin';
}

/** Жабық беттерді қорғау */
function require_login(): void {
    if (!is_logged_in()) {
        $next = basename($_SERVER['SCRIPT_NAME']);
        flash_set('Бұл бетті көру үшін алдымен жүйеге кіріңіз.', 'error');
        header('Location: login.php?next=' . urlencode($next));
        exit;
    }
}

/** Кірген адам login/register беттерін көрмеуі керек */
function redirect_if_logged_in(): void {
    if (is_logged_in()) {
        header('Location: profile.php');
        exit;
    }
}

/** Пайдаланушыны сессияға жазу (кіргеннен кейін) */
function login_user(array $user): void {
    session_regenerate_id(true);            // session fixation-нан қорғау
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['name']    = $user['name'];
    $_SESSION['role']    = $user['role'];
}

/** Сессияны толық жою */
function logout_user(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/* ---------- CSRF ---------- */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): bool {
    return isset($_POST['csrf'], $_SESSION['csrf'])
        && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

/* ---------- Flash-хабарламалар ---------- */
function flash_set(string $msg, string $type = 'success'): void {
    $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
}

function flash_get(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}
