<?php
// PDO арқылы MySQL-ге қосылу
$host    = 'localhost';
$dbname  = 'minishop';
$dbuser  = 'root';     // XAMPP-та әдетте root
$dbpass  = '';         // XAMPP-та әдетте бос
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $dbuser, $dbpass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Дерекқорға қосылу мүмкін болмады. includes/db.php баптауларын тексеріңіз.');
}
