<?php
require_once 'includes/auth.php';

// Шығу тек POST + CSRF токенімен жұмыс істейді
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_check()) {
    logout_user();
    session_start();                         // жаңа сессия — flash хабарлама үшін
    flash_set('Сіз жүйеден шықтыңыз.');
}

header('Location: login.php');
exit;
