<?php
require_once 'includes/auth.php';
redirect_if_logged_in();

$errors = [];
$name = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check()) {
        $errors[] = 'Қауіпсіздік қатесі. Бетті жаңартып, қайта көріңіз.';
    }

    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    // Валидация
    if (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
        $errors[] = 'Аты-жөні 2–100 таңба аралығында болуы керек.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 100) {
        $errors[] = 'Электрондық пошта дұрыс емес.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Құпиясөз кемінде 6 таңба болуы керек.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Құпиясөздер сәйкес келмейді.';
    }

    // Email бос па?
    if (!$errors) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = 'Бұл email бұрын тіркелген.';
        }
    }

    // Дерекқорға сақтау (пароль хэштеліп сақталады)
    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)');
        $stmt->execute([$name, $email, $hash]);

        flash_set('Тіркелу сәтті өтті! Енді жүйеге кіре аласыз.');
        header('Location: login.php');
        exit;
    }
}

$pageTitle = 'Тіркелу — MiniShop';
require 'includes/header.php';
?>
<div class="auth-background">
    <div class="auth-card">
        <div class="auth-icon">✨</div>
        <p class="eyebrow">MINISHOP ҚАУЫМДАСТЫҒЫ</p>
        <h1>Тіркелу</h1>
        <p class="muted">Жаңа аккаунт ашу үшін форманы толтырыңыз.</p>

        <?php if ($errors): ?>
            <div class="alert error">
                <ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
            </div>
        <?php endif; ?>

        <form method="post" novalidate>
            <?= csrf_field() ?>

            <label for="name">Аты-жөніңіз</label>
            <input id="name" name="name" type="text" required minlength="2"
                   placeholder="Аты-жөніңіз" value="<?= e($name) ?>">

            <label for="email">Электрондық пошта</label>
            <input id="email" name="email" type="email" required
                   placeholder="name@example.com" value="<?= e($email) ?>">

            <label for="password">Құпиясөз</label>
            <input id="password" name="password" type="password" required minlength="6"
                   placeholder="Кемінде 6 таңба">

            <label for="confirm">Құпиясөзді қайталау</label>
            <input id="confirm" name="confirm" type="password" required minlength="6"
                   placeholder="Құпиясөзді қайталаңыз">

            <button class="btn full-width" type="submit">Аккаунт ашу</button>
        </form>

        <p class="switch-text">Аккаунтыңыз бар ма? <a href="login.php"><b>Кіру</b></a></p>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
