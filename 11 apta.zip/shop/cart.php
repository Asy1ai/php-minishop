<?php
require_once 'includes/auth.php';
require_login();                              // себет тек кірген пайдаланушыға

$pageTitle = 'Себет — MiniShop';
require 'includes/header.php';
?>
<div class="container section-space">
    <p class="eyebrow">СІЗДІҢ ТАҢДАУЫҢЫЗ</p>
    <h1>Менің себетім 🛒</h1>
    <p class="muted">Себетке қосқан тауарларыңызды осында көресіз.</p>

    <div class="empty-box">
        <p class="muted">Себет әзірге бос. Себет функциясы 14-аптада қосылады.</p>
        <a class="btn" href="products.php">Тауарларға өту</a>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
