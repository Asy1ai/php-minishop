<?php
require_once 'includes/auth.php';
$pageTitle = 'Тауарлар — MiniShop';
require 'includes/header.php';
?>
<div class="container section-space">
    <p class="eyebrow">MINISHOP КАТАЛОГЫ</p>
    <h1>Барлық тауарлар</h1>

    <div class="empty-box">
        <p class="muted">Тауарлар каталогы 12–13 апталарда қосылады (CRUD, іздеу, сүзгі).</p>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
