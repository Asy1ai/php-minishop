<?php
require_once 'includes/auth.php';
$pageTitle = 'MiniShop — Онлайн дүкен';
require 'includes/header.php';
?>
<div class="container">
    <?php if ($flash): ?>
        <div class="alert <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
    <?php endif; ?>

    <div class="hero">
        <div class="hero-text">
            <p class="eyebrow">MINISHOP ОНЛАЙН ДҮКЕНІ</p>
            <h1>Сүйікті тауарларың <span>бір жерде!</span></h1>
            <p>
                <?php if (is_logged_in()): ?>
                    Қош келдіңіз, <b><?= e($_SESSION['name']) ?></b>! Тауарларды таңдап, сатып алуды бастаңыз.
                <?php else: ?>
                    Өзіңізге ұнайтын тауарларды таңдап, себетке қосыңыз. Бастау үшін тіркеліңіз.
                <?php endif; ?>
            </p>

            <?php if (is_logged_in()): ?>
                <a class="btn" href="products.php">Каталогқа өту →</a>
            <?php else: ?>
                <a class="btn" href="register.php">Тіркелу →</a>
            <?php endif; ?>
        </div>

        <div class="hero-picture">
            <img src="https://images.unsplash.com/photo-1607082349566-187342175e2f?auto=format&fit=crop&w=900&q=85"
                 alt="Онлайн дүкендегі сауда">
        </div>
    </div>

    <div class="advantages">
        <div class="advantage"><span>🚚</span><div><b>Жылдам жеткізу</b><p>Ыңғайлы сауда</p></div></div>
        <div class="advantage"><span>🛡️</span><div><b>Сапалы тауарлар</b><p>Таңдаулы өнімдер</p></div></div>
        <div class="advantage"><span>💜</span><div><b>Қолдау қызметі</b><p>Сізге көмектесеміз</p></div></div>
    </div>
</div>
<?php require 'includes/footer.php'; ?>
