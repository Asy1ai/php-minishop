document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('menuBtn');
    const nav = document.getElementById('nav');
    if (btn && nav) {
        btn.addEventListener('click', () => nav.classList.toggle('open'));
    }
    document.querySelectorAll('select[data-autosubmit]').forEach((sel) => {
        sel.addEventListener('change', () => sel.form && sel.form.submit());
    });
});
