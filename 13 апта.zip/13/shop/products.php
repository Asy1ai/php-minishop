<?php
require_once 'includes/auth.php';

const PER_PAGE = 8;

$sortOptions = [
    'new'        => ['Жаңалары алдымен',   'created_at DESC, id DESC'],
    'old'        => ['Ескілері алдымен',   'created_at ASC, id ASC'],
    'price_asc'  => ['Бағасы: арзаннан қымбатқа', 'price ASC, id DESC'],
    'price_desc' => ['Бағасы: қымбаттан арзанға', 'price DESC, id DESC'],
    'name_asc'   => ['Атауы: А → Я',       'name ASC, id DESC'],
    'name_desc'  => ['Атауы: Я → А',       'name DESC, id DESC'],
];

function get_text(string $key, int $maxLen = 100): string {
    $v = $_GET[$key] ?? '';
    if (!is_string($v)) return '';
    return mb_substr(trim($v), 0, $maxLen);
}

function valid_date(string $s): bool {
    $d = DateTime::createFromFormat('Y-m-d', $s);
    return $d !== false && $d->format('Y-m-d') === $s;
}

function catalog_url(array $params): string {
    $params = array_filter($params, fn($v) => $v !== '' && $v !== null);
    if (isset($params['sort'])   && $params['sort'] === 'new') unset($params['sort']);
    if (isset($params['page'])   && (int)$params['page'] <= 1)  unset($params['page']);
    return 'products.php' . ($params ? '?' . http_build_query($params) : '');
}

$q        = get_text('q');
$category = get_text('category', 50);
$dateFrom = get_text('date_from', 10);
$dateTo   = get_text('date_to', 10);
$sort     = get_text('sort', 20);
$notice   = null;

if (!isset($sortOptions[$sort])) $sort = 'new';

$categories = $pdo->query(
    "SELECT DISTINCT category FROM products WHERE category <> '' ORDER BY category"
)->fetchAll(PDO::FETCH_COLUMN);
if ($category !== '' && !in_array($category, $categories, true)) $category = '';

if ($dateFrom !== '' && !valid_date($dateFrom)) $dateFrom = '';
if ($dateTo   !== '' && !valid_date($dateTo))   $dateTo   = '';
if ($dateFrom !== '' && $dateTo !== '' && $dateFrom > $dateTo) {
    [$dateFrom, $dateTo] = [$dateTo, $dateFrom];
    $notice = 'Күн аралығы қате болғандықтан, «бастап» және «дейін» мәндері ауыстырылды.';
}

$where  = [];
$params = [];

if ($q !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
    $where[]          = '(name LIKE :q1 OR description LIKE :q2)';
    $params[':q1']    = $like;
    $params[':q2']    = $like;
}
if ($category !== '') {
    $where[]              = 'category = :category';
    $params[':category']  = $category;
}
if ($dateFrom !== '') {
    $where[]               = 'created_at >= :date_from';
    $params[':date_from']  = $dateFrom . ' 00:00:00';
}
if ($dateTo !== '') {
    $where[]             = 'created_at < :date_to';
    $params[':date_to']  = date('Y-m-d', strtotime($dateTo . ' +1 day')) . ' 00:00:00';
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$countStmt = $pdo->prepare("SELECT COUNT(*) FROM products $whereSql");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();

$totalPages = max(1, (int)ceil($total / PER_PAGE));
$page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
$page = ($page === false || $page < 1) ? 1 : min($page, $totalPages);
$offset = ($page - 1) * PER_PAGE;

$orderSql = $sortOptions[$sort][1];
$stmt = $pdo->prepare(
    "SELECT id, name, price, category, image, created_at
       FROM products
       $whereSql
   ORDER BY $orderSql
      LIMIT :limit OFFSET :offset"
);
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v, PDO::PARAM_STR);
}
$stmt->bindValue(':limit',  PER_PAGE, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset,  PDO::PARAM_INT);
$stmt->execute();
$products = $stmt->fetchAll();

$state = [
    'q' => $q, 'category' => $category,
    'date_from' => $dateFrom, 'date_to' => $dateTo, 'sort' => $sort,
];
$isFiltered = ($q !== '' || $category !== '' || $dateFrom !== '' || $dateTo !== '');

$from = $total ? $offset + 1 : 0;
$to   = $total ? $offset + count($products) : 0;

$pageNumbers = [];
for ($i = 1; $i <= $totalPages; $i++) {
    if ($i === 1 || $i === $totalPages || abs($i - $page) <= 2) {
        $pageNumbers[] = $i;
    } elseif (end($pageNumbers) !== '...') {
        $pageNumbers[] = '...';
    }
}

$pageTitle = 'Тауарлар — MiniShop';
require 'includes/header.php';
?>
<div class="container section-space">
    <?php if ($flash): ?>
        <div class="alert <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div>
    <?php endif; ?>
    <?php if ($notice): ?>
        <div class="alert error"><?= e($notice) ?></div>
    <?php endif; ?>

    <p class="eyebrow">MINISHOP КАТАЛОГЫ</p>
    <h1>Барлық тауарлар</h1>

    <form class="filter-form" method="get" action="products.php">
        <div class="filter-search">
            <label for="q">Іздеу</label>
            <input type="text" id="q" name="q" maxlength="100"
                   placeholder="Атауы немесе сипаттамасы бойынша..."
                   value="<?= e($q) ?>">
        </div>

        <div>
            <label for="category">Санат</label>
            <select id="category" name="category" data-autosubmit>
                <option value="">Барлық санаттар</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= e($c) ?>" <?= $c === $category ? 'selected' : '' ?>><?= e($c) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div>
            <label for="date_from">Қосылған күні: бастап</label>
            <input type="date" id="date_from" name="date_from"
                   max="<?= e(date('Y-m-d')) ?>" value="<?= e($dateFrom) ?>">
        </div>

        <div>
            <label for="date_to">дейін</label>
            <input type="date" id="date_to" name="date_to"
                   max="<?= e(date('Y-m-d')) ?>" value="<?= e($dateTo) ?>">
        </div>

        <div>
            <label for="sort">Сұрыптау</label>
            <select id="sort" name="sort" data-autosubmit>
                <?php foreach ($sortOptions as $key => $opt): ?>
                    <option value="<?= e($key) ?>" <?= $key === $sort ? 'selected' : '' ?>><?= e($opt[0]) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="filter-buttons">
            <button type="submit" class="btn">Іздеу</button>
            <?php if ($isFiltered || $sort !== 'new'): ?>
                <a class="btn secondary" href="products.php">Тазалау</a>
            <?php endif; ?>
        </div>
    </form>

    <p class="muted result-info">
        <?php if ($total): ?>
            Табылды: <b><?= $total ?></b> тауар · көрсетілгені: <?= $from ?>–<?= $to ?>
            · бет <?= $page ?> / <?= $totalPages ?>
        <?php else: ?>
            Табылды: <b>0</b> тауар
        <?php endif; ?>
    </p>

    <?php if (!$products): ?>
        <div class="empty-box">
            <p class="muted">
                <?= $isFiltered ? 'Сұранысыңызға сәйкес тауар табылмады.' : 'Әзірге тауар жоқ.' ?>
            </p>
            <?php if ($isFiltered): ?>
                <a class="btn" href="products.php">Сүзгілерді тазалау</a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="products" style="margin-top:22px">
            <?php foreach ($products as $p): $img = product_image_url($p['image']); ?>
                <div class="product-card">
                    <a href="product.php?id=<?= (int)$p['id'] ?>">
                        <?php if ($img): ?>
                            <img class="product-image" src="<?= e($img) ?>" alt="<?= e($p['name']) ?>">
                        <?php else: ?>
                            <div class="product-image no-image">🛍️</div>
                        <?php endif; ?>
                    </a>
                    <div class="product-info">
                        <p class="product-category"><?= e($p['category'] ?: 'Санатсыз') ?></p>
                        <h3><a href="product.php?id=<?= (int)$p['id'] ?>"><?= e($p['name']) ?></a></h3>
                        <p class="product-date">📅 <?= e(date('d.m.Y', strtotime($p['created_at']))) ?></p>
                        <div class="product-bottom">
                            <span class="price"><?= e(money($p['price'])) ?></span>
                            <a class="btn" href="product.php?id=<?= (int)$p['id'] ?>">Көру</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
            <div class="pagination" aria-label="Беттер">
                <?php if ($page > 1): ?>
                    <a href="<?= e(catalog_url($state + ['page' => $page - 1])) ?>">← Алдыңғы</a>
                <?php else: ?>
                    <span class="disabled">← Алдыңғы</span>
                <?php endif; ?>

                <?php foreach ($pageNumbers as $n): ?>
                    <?php if ($n === '...'): ?>
                        <span class="dots">…</span>
                    <?php elseif ($n === $page): ?>
                        <span class="current"><?= $n ?></span>
                    <?php else: ?>
                        <a href="<?= e(catalog_url($state + ['page' => $n])) ?>"><?= $n ?></a>
                    <?php endif; ?>
                <?php endforeach; ?>

                <?php if ($page < $totalPages): ?>
                    <a href="<?= e(catalog_url($state + ['page' => $page + 1])) ?>">Келесі →</a>
                <?php else: ?>
                    <span class="disabled">Келесі →</span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php require 'includes/footer.php'; ?>
